local heist_table = {
    ["branchbank"] = true,
    ["firestarter_3"] = true,
    ["roberts"] = true,
    ["big"] = true,
    ["bex"] = true
}
local heist_id = Global.level_data and Global.level_data.level_id

if not heist_table[heist_id] then
    return
end

local deposit_box_units = {
    ["@ID7999172"] = true, ["@IDe93c9b2"] = true, ["@IDa95e021"] = true, ["@ID5dcd177"] =true,
    ["@ID8d8c766"] = true, ["@ID5dcd177"] = true, ["@IDd2d7c5a"] = true
}

local function Interact()
    for _,unit in pairs(World:find_units_quick("all", 1)) do
        local interaction = (alive(unit) and (unit['interaction'] ~= nil)) and unit:interaction()
        local tweak_id = interaction and interaction.tweak_data
        local tweak = tweak_id and tweak_data.interaction[tweak_id]
        if tweak then
            local base = unit:base()
            local unit_id = string.sub(unit:name():t(), 1, 10)
            if tweak.is_lockpicking and deposit_box_units[unit_id] then
                interaction:interact(managers.player:player_unit())
            end
        end
    end
end

Hooks:PostHook(MissionScriptElement, "on_executed", "lazystealth", function(self)
    if managers.groupai:state():whisper_mode() then
        if self._id == 102890 and self._editor_name == "timer_done"
        or self._id == 102136 and self._editor_name == "vaultOpened"
        or self._id == 105832 and self._editor_name == "Player entered vault - stealth"
        or self._id == 103917 and self._editor_name == "picked_up_bag001" then
            Interact()
            managers.chat:send_message(ChatManager.GAME, managers.network.account:username() or "Offline", "Heist succesfully stealthed, opening lockboxes...")
        end
    end
end)
